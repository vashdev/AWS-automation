import json
import os
import sys
import datetime
import re
import logging
from copy import deepcopy
import csv
import boto3
from io import BytesIO
from botocore.client import Config
class PasswordVault:
    global pamDictionary
    def __init__(self, pamAppCode, pamEnvCode, pamObjRef):

        self.pamAppCode=pamAppCode
        self.pamEnvCode=pamEnvCode
        self.pamObjRef=pamObjRef
        self.getPamDictionary()


    #Returns s3 buket name
    def getS3Bucket(self):
         ##Convert parameters to derive AWS S3 Bucket for PAM
         ##AWS_VREF should be sent as -D System Property
         s3Bucket="fnma-"+os.environ['AWS_VREF']+"-app-"+self.pamAppCode.lower()+"-"+self.pamEnvCode.lower()
         #print (s3Bucket)
         return s3Bucket

    #Returns PAM file data in dictionary
    def getPamDictionary(self):
        # Bucket,Key
        #fnma-pvdevl-edl-us-east-1-app-fre-d ,fre01-devl-edl-edl-ad
        pamDictionary={}
        client=boto3.client('s3',config=Config(signature_version='s3v4'))
        pamS3Buket=self.getS3Bucket()
        pamObj = client.get_object(Bucket=pamS3Buket, Key=self.pamObjRef)
        lines=pamObj['Body'].read().decode('utf-8').splitlines(True)
        reader = csv.reader(lines,delimiter='=')
        for kv in reader:
               pamDictionary[kv[0]]=kv[1]
        self.pamDictionary = pamDictionary.copy()
        return self.pamDictionary

    #retuns Address from PAM Dictionary
    def getAddress(self):
        return self.pamDictionary['Address']

    #retuns Account from PAM Dictionary
    def getAccount(self):
        return self.pamDictionary['Account']

    #retuns Password from PAM Dictionary
    def getPassword(self):
        return self.pamDictionary['Password']
